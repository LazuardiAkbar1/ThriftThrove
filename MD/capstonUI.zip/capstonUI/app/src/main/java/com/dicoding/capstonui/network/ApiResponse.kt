package com.dicoding.capstonui.network

data class ApiResponse(
    val success: Boolean,
    val message: String
)